"""OpenAI-compatible response models for FastRouter SDK"""

from typing import Dict, List, Any, Optional, Union


class Usage:
    """Usage statistics for the completion"""
    
    def __init__(self, data: Dict[str, Any]):
        self._data = data
        self.chat_id = data.get('chat_id')
        self.completion_tokens = data.get('completion_tokens', 0)
        self.prompt_tokens = data.get('prompt_tokens', 0) 
        self.total_tokens = data.get('total_tokens', 0)
        self.cost = data.get('cost', 0.0)
        self.provider = data.get('provider')
        self.completion_tokens_details = data.get('completion_tokens_details', {})
        self.prompt_tokens_details = data.get('prompt_tokens_details', {})
    
    def __repr__(self):
        return f"Usage(completion_tokens={self.completion_tokens}, prompt_tokens={self.prompt_tokens}, total_tokens={self.total_tokens})"


class Message:
    """Chat message object"""
    
    def __init__(self, data: Dict[str, Any]):
        self._data = data
        self.role = data.get('role', '')
        self.content = data.get('content', '')
        self.annotations = data.get('annotations', [])
    
    def __repr__(self):
        return f"Message(role='{self.role}', content='{self.content[:50]}{'...' if len(self.content) > 50 else ''}')"


class Choice:
    """Individual choice in the completion response"""
    
    def __init__(self, data: Dict[str, Any]):
        self._data = data
        self.index = data.get('index', 0)
        self.message = Message(data.get('message', {}))
        self.finish_reason = data.get('finish_reason')
    
    def __repr__(self):
        return f"Choice(index={self.index}, message={self.message}, finish_reason='{self.finish_reason}')"


class ChatCompletion:
    """Main chat completion response object - OpenAI compatible"""
    
    def __init__(self, data: Dict[str, Any]):
        self._data = data  # Keep original data for backward compatibility
        
        # Core OpenAI-compatible fields
        self.id = data.get('id', '')
        self.object = data.get('object', 'chat.completion')
        self.created = data.get('created')
        self.model = data.get('model', '')
        self.service_tier = data.get('service_tier', 'default')
        
        # Choices - convert to Choice objects
        choices_data = data.get('choices', [])
        self.choices = [Choice(choice) for choice in choices_data]
        
        # Usage statistics
        usage_data = data.get('usage', {})
        self.usage = Usage(usage_data) if usage_data else None
        
        # FastRouter-specific fields
        self.guardrails = data.get('guardrails', {})
        self.citations = data.get('citations')
    
    def __repr__(self):
        return f"ChatCompletion(id='{self.id}', model='{self.model}', choices={len(self.choices)})"
    
    def to_dict(self) -> Dict[str, Any]:
        """Return the original dictionary representation for backward compatibility"""
        return self._data


class HealthResponse:
    """Health check response object"""
    
    def __init__(self, data: Union[Dict[str, Any], str]):
        if isinstance(data, str):
            self._data = {"status": data}
            self.status = data
        else:
            self._data = data
            self.status = data.get('status', data.get('content', 'Unknown'))
    
    def __repr__(self):
        return f"HealthResponse(status='{self.status}')"
    
    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation"""
        return self._data
